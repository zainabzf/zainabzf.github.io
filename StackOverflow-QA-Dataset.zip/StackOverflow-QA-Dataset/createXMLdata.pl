#!/usr/bin/perl

# use module
use XML::Simple;
use Data::Dumper;
use File::Path;

if (! @ARGV) {
	print "\nIncorrect format enter ./createXMLdata.pl TrainQuestionNames.txt TrainAnswerNames.txt TestQuestionNames.txt post.xml dataset.xml\n\n"; 
	exit 0;
	}

sub trim($)
{
	my $string = shift;
	$string =~ s/^\s+//;
	$string =~ s/\s+$//;
	return $string;
}


$TQN = $ARGV[0]; #"TrainQuestionNames.txt"
$TAN= $ARGV[1]; #"TrainAnswerNames.txt"
$TESTQN = $ARGV[2]; #TestQuestionNames.txt
$postxml=$ARGV[3];
$output = $ARGV[4];

open (TQN, $TQN ) or die " cannot read $TQN";
my %TQNhash = ();
while(<TQN>){
	chomp();
	$new=trim($_);
	$TQNhash{$new}++;
}

open (TAN, $TAN ) or die " cannot read $TAN";
my %TANhash = ();
while(<TAN>){
	chomp();
	$new=trim($_);
	$TANhash{$new}++;
}

open (TESTQN, $TESTQN) or die " cannot read $TESTQN";
my %TESTQNhash = ();
while(<TESTQN>){
	chomp();
	$new=trim($_);
	$TESTQNhash{$new}++;
}

###############################################################################################################

#$xml = new XML::Simple (KeyAttr=>[]);
#$data = $xml->XMLin($postxml);


#open(output,"+>$output") or die " cannot create dataset.xml";
#print output "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<posts>\n";


#$xmlout = new XML::Simple (NoAttr=>1, RootName=>'row', NoIndent => 1,NoSort => 0,NoEscape =>0,NumericEscape => 0);
#$countTQN=0;
#$countTAN=0;
#$countTESTQN=0;
#foreach $r (@{$data->{row}})
#{
#	if (exists $TQNhash{$r->{Id}}){
#		if ($r->{PostTypeId} =='1' ){
#			print "Q", $r->{Id}," ";
#			$countTQN++;
#			print output $xmlout->XMLout($r),"\n"; 
#		}
#	}
#	if (exists $TANhash{$r->{Id}}){
#		if($r->{PostTypeId} =='2' ){
#			print "A", $r->{Id}," ";
#			$countTAN++;
#			print output $xmlout->XMLout($r),"\n";
#		}
#	}
		
#	if (exists $TESTQNhash{$r->{Id}}){
#		if($r->{PostTypeId} =='1' ){
#			print "TQ", $r->{Id}," ";
#			$countTESTQN++;			
#			print output $xmlout->XMLout($r),"\n";
#		}
#	}
#}
#print output "</posts>";
#print "\ncountTrain Questions $countTQN \n";
#print "countTrain Answers $countTAN \n";
#print "countTest Questions $countTESTQN \n";

###############################################################################################################
##different method
open(readin, $postxml) or die"cannot open $postxml";

open(output,"+>$output") or die " cannot create dataset.xml";

$countTQN=0;
$countTAN=0;
$countTESTQN=0;
while(<readin>){
	if($_ =~ m/<\?xml version=\"1.0\" encoding=\"utf-8\"\?>/){
		print output $_;
	}
	elsif( $_ =~ m/<posts>/ ){
		print output $_;	
	}
	elsif ( $_ =~ m/<\/posts>/){
		print output $_;	
	}
	
	elsif ($_ =~ m/<row Id=\"(\d+)\" PostTypeId=\"(\d+)\"/ ){
		$Id = $1;
		$PostTypeId = $2;

		if(exists $TQNhash{$Id}){
			if ( $PostTypeId  =='1' ){
				print "Q", $Id," ";
				$countTQN++;
				print output $_; 
			}
		}
		elsif (exists $TANhash{$Id}){
			if($PostTypeId =='2' ){
				print "A", $Id," ";
				$countTAN++;
				print output $_;
			}
		}
		
		elsif (exists $TESTQNhash{$Id}){
			if($PostTypeId =='1' ){
				print "TQ", $Id," ";
				$countTESTQN++;			
				print output $_;
			}
		}
			
	
	}
}
print "\ncountTrain Questions $countTQN \n";
print "countTrain Answers $countTAN \n";
print "countTest Questions $countTESTQN \n";


