--------------------------------------------
Please cite the following if you make use of this dataset:

@inproceedings{zolaktaf2011modeling,
  title={Modeling community question-answering archives},
  author={Zolaktaf, Zainab and Riahi, Fatemeh and Shafiei, Mahdi and Milios, Evangelos},
  booktitle={Proceedings of the Workshop on Computational Social Science and the Wisdom of Crowds at NIPS},
  year={2011}
}
--------------------------------------------
For description of dataset extraction procedure refer to dataset-README.pdf file.
--------------------------------------------

FileName	&	Description

createXMLdata.pl	&	extracts the dataset from posts.xml (call using ./createXMLdata.pl TrainQuestionNames.txt TrainAnswerNames.txt TestQuestionNames.txt posts.xml dataset.xml>out.txt)
out.txt	&	disregard this, it is the output generated from createXMLdata.pl
dataset.xml	&	the dataset
TestQuestionNames.txt	&	questionIDs for testing, 822 
TrainAnswerNames.txt	&	answerIDs for training, 15822
TrainQuestionNames.txt	&	questionIDs for training, 4184
TrainQuestionAnswerNAmes.txt	&	pairs of TrainQuestionID-TrainAnswerID for question answer pair retrieval, 15822
testdups852.txt	&	pair of TestQuestionID TrainQuestionID, gives you the duplicates, 852



